class Figure:
    def __init__(self):
        pass
    def triangle(self,num):
        z=1
        t=''
        for i in range(num):
            t+="*"
            print(t)
        
                
        
